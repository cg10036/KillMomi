﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KillMomi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DisableAllButtons()
        {
            MomiSuspend.Enabled = false;
            MomiResume.Enabled = false;
            NetclassSuspend.Enabled = false;
            NetclassResume.Enabled = false;
            VpnConnect.Enabled = false;
            VpnDisconnect.Enabled = false;
        }

        private void EnableAllButtons()
        {
            MomiSuspend.Enabled = true;
            MomiResume.Enabled = true;
            NetclassSuspend.Enabled = true;
            NetclassResume.Enabled = true;
            VpnConnect.Enabled = true;
            VpnDisconnect.Enabled = true;
        }

        private void MomiSuspend_Click(object sender, EventArgs e)
        {
            DisableAllButtons();
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows");
                FileInfo[] files = directoryInfo.GetFiles("*.*", SearchOption.TopDirectoryOnly);
                // foreach (FileInfo fileInfo in files)
                label.Text = "1";
                progressBar.Maximum = files.Length;
                for(int i = 0;i < files.Length;i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo = files[i];
                    if (Path.GetFileNameWithoutExtension(fileInfo.FullName).ToLower().StartsWith("processhide"))
                    {
                        try
                        {
                            fileInfo.Attributes = FileAttributes.Normal;
                            string fullName = fileInfo.FullName;
                            if (Path.GetExtension(fullName).Contains("exe"))
                            {
                                new FileInfo(Directory.GetCurrentDirectory() + "\\Command.exe")
                                {
                                    Attributes = FileAttributes.Normal
                                }.CopyTo(fullName, true);
                            }
                            if (Path.GetExtension(fullName).Contains("dll"))
                            {
                                new FileInfo(Directory.GetCurrentDirectory() + "\\CommandDLL.dll")
                                {
                                    Attributes = FileAttributes.Normal
                                }.CopyTo(fullName, true);
                            }
                            FileInfo fileInfo2 = new FileInfo(fullName);
                            fileInfo2.Attributes = (FileAttributes.ReadOnly | FileAttributes.Hidden | FileAttributes.System);
                        }
                        catch { }
                    }
                }

            }
            catch { }
            List<string> lists = new List<string>();
            try
            {
                label.Text = "2";
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0;i < files.Length;i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    try
                    {
                        string fullName = fileInfo2.FullName;
                        X509Certificate2 x509Certificate = new X509Certificate2(File.ReadAllBytes(fullName));
                        string subject = x509Certificate.Subject;
                        if (subject.Contains("JNESS") || subject.Contains("제이니스"))
                        {
                            lists.Add(fullName);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch { }
            try
            {
                label.Text = "3";
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows\\SysWOW64");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    try
                    {
                        string fullName = fileInfo2.FullName;
                        X509Certificate2 x509Certificate = new X509Certificate2(File.ReadAllBytes(fullName));
                        string subject = x509Certificate.Subject;
                        if (subject.Contains("JNESS") || subject.Contains("제이니스"))
                        {
                            lists.Add(fullName);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch { }
            try
            {
                label.Text = "4";
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows\\System32");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    try
                    {
                        string fullName = fileInfo2.FullName;
                        X509Certificate2 x509Certificate = new X509Certificate2(File.ReadAllBytes(fullName));
                        string subject = x509Certificate.Subject;
                        if (subject.Contains("JNESS") || subject.Contains("제이니스"))
                        {
                            lists.Add(fullName);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch { }
            Process[] processes = Process.GetProcesses();
            label.Text = "5";
            progressBar.Maximum = lists.Count;
            for (int i = 0;i < lists.Count;i++)
            {
                progressBar.Value = i;
                Application.DoEvents();
                string path = lists[i];
                for (int j = 0; j < processes.Length; j++)
                {
                    Process process = processes[j];
                    if (process.ProcessName.StartsWith(Path.GetFileNameWithoutExtension(path)))
                    {
                        try
                        {
                            if (process.Threads[0].WaitReason == ThreadWaitReason.Suspended)
                            {
                                continue;
                            }
                            ProcessExtension.Suspend(process);
                        }
                        catch { }
                    }
                }
            }
            progressBar.Value = progressBar.Maximum;
            label.Text = "Done";
            MessageBox.Show("Done!");
            EnableAllButtons();
        }

        private void MomiResume_Click(object sender, EventArgs e)
        {
            DisableAllButtons();
            List<string> lists = new List<string>();
            try
            {
                label.Text = "1";
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    try
                    {
                        string fullName = fileInfo2.FullName;
                        X509Certificate2 x509Certificate = new X509Certificate2(File.ReadAllBytes(fullName));
                        string subject = x509Certificate.Subject;
                        if (subject.Contains("JNESS") || subject.Contains("제이니스"))
                        {
                            lists.Add(fullName);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch { }
            try
            {
                label.Text = "2";
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows\\SysWOW64");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    try
                    {
                        string fullName = fileInfo2.FullName;
                        X509Certificate2 x509Certificate = new X509Certificate2(File.ReadAllBytes(fullName));
                        string subject = x509Certificate.Subject;
                        if (subject.Contains("JNESS") || subject.Contains("제이니스"))
                        {
                            lists.Add(fullName);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch { }
            try
            {
                label.Text = "3";
                DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.System)) + "Windows\\System32");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    try
                    {
                        string fullName = fileInfo2.FullName;
                        X509Certificate2 x509Certificate = new X509Certificate2(File.ReadAllBytes(fullName));
                        string subject = x509Certificate.Subject;
                        if (subject.Contains("JNESS") || subject.Contains("제이니스"))
                        {
                            lists.Add(fullName);
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch { }
            Process[] processes = Process.GetProcesses();
            label.Text = "4";
            progressBar.Maximum = lists.Count;
            for (int i = 0; i < lists.Count; i++)
            {
                progressBar.Value = i;
                Application.DoEvents();
                string path = lists[i];
                for (int j = 0; j < processes.Length; j++)
                {
                    Process process = processes[j];
                    if (process.ProcessName.StartsWith(Path.GetFileNameWithoutExtension(path)))
                    {
                        try
                        {
                            if (process.Threads[0].WaitReason != ThreadWaitReason.Suspended)
                            {
                                continue;
                            }
                            ProcessExtension.Suspend(process);
                        }
                        catch { }
                    }
                }
            }
            progressBar.Value = progressBar.Maximum;
            label.Text = "Done";
            MessageBox.Show("Done!");
            EnableAllButtons();
        }

        private void NetclassSuspend_Click(object sender, EventArgs e)
        {
            DisableAllButtons();
            try
            {
                label.Text = "1";
                DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Program Files\\NetClassClient8");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    Process[] processes = Process.GetProcesses();
                    for(int j = 0;j < processes.Length;j++)
                    {
                        Process process = processes[j];
                        if(process.ProcessName.StartsWith(Path.GetFileNameWithoutExtension(fileInfo2.FullName)))
                        {
                            try
                            {
                                if(process.Threads[0].WaitReason == ThreadWaitReason.Suspended)
                                {
                                    continue;
                                }
                                ProcessExtension.Suspend(process);
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
            progressBar.Value = progressBar.Maximum;
            label.Text = "Done";
            MessageBox.Show("Done!");
            EnableAllButtons();
        }

        private void NetclassResume_Click(object sender, EventArgs e)
        {
            DisableAllButtons();
            try
            {
                label.Text = "1";
                DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Program Files\\NetClassClient8");
                FileInfo[] files = directoryInfo.GetFiles("*.exe", SearchOption.TopDirectoryOnly);
                progressBar.Maximum = files.Length;
                // foreach (FileInfo fileInfo2 in files)
                for (int i = 0; i < files.Length; i++)
                {
                    progressBar.Value = i;
                    Application.DoEvents();
                    FileInfo fileInfo2 = files[i];
                    Process[] processes = Process.GetProcesses();
                    for (int j = 0; j < processes.Length; j++)
                    {
                        Process process = processes[j];
                        if (process.ProcessName.StartsWith(Path.GetFileNameWithoutExtension(fileInfo2.FullName)))
                        {
                            try
                            {
                                if (process.Threads[0].WaitReason != ThreadWaitReason.Suspended)
                                {
                                    continue;
                                }
                                ProcessExtension.Resume(process);
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }
            progressBar.Value = progressBar.Maximum;
            label.Text = "Done";
            MessageBox.Show("Done!");
            EnableAllButtons();
        }

        private void VpnConnect_Click(object sender, EventArgs e)
        {
            DisableAllButtons();
            progressBar.Value = 0;
            Application.DoEvents();
            Process process = Process.Start("powershell.exe", "Add-VpnConnection -Name \"chika.kr\" -ServerAddress \"vpn1.chika.kr\" -TunnelType L2tp -L2tpPsk railgun -Force");
            process.WaitForExit();
            process = Process.Start("powershell.exe", "rasdial chika.kr sunrin1 tsuki");
            process.WaitForExit();
            label.Text = "Done";
            MessageBox.Show("Done!");
            EnableAllButtons();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisableAllButtons();
            progressBar.Value = 0;
            Application.DoEvents();
            Process process = Process.Start("powershell.exe", "rasdial /d");
            process.WaitForExit();
            label.Text = "Done";
            MessageBox.Show("Done!");
            EnableAllButtons();
        }
    }
}
